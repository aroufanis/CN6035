-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: May 26, 2025 at 10:51 PM
-- Server version: 11.7.2-MariaDB-ubu2404
-- PHP Version: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eroufanis22b_db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `reservation_uuid` char(36) NOT NULL DEFAULT uuid(),
  `user_id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `reservation_datetime` datetime NOT NULL,
  `guests` int(11) NOT NULL DEFAULT 1,
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `reservation_uuid`, `user_id`, `restaurant_id`, `reservation_datetime`, `guests`, `status`, `created_at`) VALUES
(1, 'bc7e227c-97c7-41ba-8be2-883b754869ac', 1, 13, '2025-05-29 20:30:00', 2, 'pending', '2025-05-26 22:49:58'),
(2, '1beaae7c-9047-4e8c-9621-67a062ef7d65', 1, 6, '2025-05-27 16:00:00', 5, 'pending', '2025-05-26 22:50:20');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `restaurant_id` int(11) NOT NULL,
  `restaurant_uuid` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`restaurant_id`, `restaurant_uuid`, `name`, `address`, `phone`, `created_at`) VALUES
(1, '74027bb5-3a83-11f0-b9d0-3681c1edf024', 'Ο Μπαρμπα-Γιάννης', 'Ανδρέα Παπανδρέου 12, Περιστέρι, Αθήνα', '2105712345', '2025-05-26 22:47:50'),
(2, '7402d67f-3a83-11f0-b9d0-3681c1edf024', 'Souvlaki King', 'Πανόρμου 89, Αμπελόκηποι, Αθήνα', '2106411123', '2025-05-26 22:47:50'),
(3, '7402da30-3a83-11f0-b9d0-3681c1edf024', 'Taverna Plaka', 'Λυσίου 17, Πλάκα, Αθήνα', '2103228765', '2025-05-26 22:47:50'),
(4, '7402dbc5-3a83-11f0-b9d0-3681c1edf024', 'My Sushi Place', 'Μιχαλακοπούλου 132, Αθήνα', '2107771122', '2025-05-26 22:47:50'),
(5, '7402dd34-3a83-11f0-b9d0-3681c1edf024', 'Pizza Roma', 'Ερμού 112, Μοναστηράκι, Αθήνα', '2103232121', '2025-05-26 22:47:50'),
(6, '7402de7a-3a83-11f0-b9d0-3681c1edf024', 'Καφενείο Λαϊκόν', 'Αναξαγόρα 18, Ψυρρή, Αθήνα', '2103456780', '2025-05-26 22:47:50'),
(7, '7402dfea-3a83-11f0-b9d0-3681c1edf024', 'Burger Republic', 'Λεωφόρος Κηφισίας 226, Χαλάνδρι, Αθήνα', '2106850099', '2025-05-26 22:47:50'),
(8, '7402e11a-3a83-11f0-b9d0-3681c1edf024', 'Το Καπηλειό', 'Φωκίωνος Νέγρη 21, Κυψέλη, Αθήνα', '2108212121', '2025-05-26 22:47:50'),
(9, '7402e272-3a83-11f0-b9d0-3681c1edf024', 'Mama India', 'Πειραιώς 123, Γκάζι, Αθήνα', '2103451122', '2025-05-26 22:47:50'),
(10, '7402e3b4-3a83-11f0-b9d0-3681c1edf024', 'The Vegan Garden', 'Δημοκρίτου 10, Κολωνάκι, Αθήνα', '2103645656', '2025-05-26 22:47:50'),
(11, '7402e4ec-3a83-11f0-b9d0-3681c1edf024', 'El Greco Tavern', 'Αδριανού 45, Θησείο, Αθήνα', '2103229090', '2025-05-26 22:47:50'),
(12, '7402e632-3a83-11f0-b9d0-3681c1edf024', 'Athens Kebab House', 'Ελευθερίου Βενιζέλου 5, Σύνταγμα, Αθήνα', '2103331122', '2025-05-26 22:47:50'),
(13, '7402e767-3a83-11f0-b9d0-3681c1edf024', 'Το Μεζεδοπωλείο της Μαρίνας', 'Νηρηίδων 25, Παλαιό Φάληρο, Αθήνα', '2109823456', '2025-05-26 22:47:50'),
(14, '7402e8a9-3a83-11f0-b9d0-3681c1edf024', 'Thai Orchid', 'Καλλιδρομίου 39, Εξάρχεια, Αθήνα', '2103819191', '2025-05-26 22:47:50'),
(15, '7402e9fe-3a83-11f0-b9d0-3681c1edf024', 'Trattoria Bella Napoli', 'Σπύρου Μερκούρη 42, Παγκράτι, Αθήνα', '2107521122', '2025-05-26 22:47:50'),
(16, '7402eb49-3a83-11f0-b9d0-3681c1edf024', 'The Falafel Spot', 'Αχαρνών 27, Αθήνα', '2108223344', '2025-05-26 22:47:50'),
(17, '7402ee11-3a83-11f0-b9d0-3681c1edf024', 'Η Αυλή', 'Πραξιτέλους 32, Αθήνα', '2103211234', '2025-05-26 22:47:50'),
(18, '7402ef99-3a83-11f0-b9d0-3681c1edf024', 'Fusion Bites', 'Μεσογείων 205, Χολαργός, Αθήνα', '2106543210', '2025-05-26 22:47:50'),
(19, '7402f0ec-3a83-11f0-b9d0-3681c1edf024', 'Κρητικό Στέκι', 'Ηρακλείτου 25, Νέα Ιωνία, Αθήνα', '2102719191', '2025-05-26 22:47:50'),
(20, '7402f22f-3a83-11f0-b9d0-3681c1edf024', 'Tex-Mex Grill', 'Αγίου Μελετίου 88, Αθήνα', '2108817171', '2025-05-26 22:47:50'),
(21, '7402f37f-3a83-11f0-b9d0-3681c1edf024', 'Brunch & Co.', 'Καλλιρόης 12, Νέος Κόσμος, Αθήνα', '2109212121', '2025-05-26 22:47:50'),
(22, '7402f4cc-3a83-11f0-b9d0-3681c1edf024', 'Στης Λέλας τα Καμώματα', 'Λεωφόρος Συγγρού 144, Καλλιθέα, Αθήνα', '2109571122', '2025-05-26 22:47:50'),
(23, '7402f61e-3a83-11f0-b9d0-3681c1edf024', 'Zorba\'s Garden', 'Κυδαθηναίων 23, Πλάκα, Αθήνα', '2103214321', '2025-05-26 22:47:50'),
(24, '7402f763-3a83-11f0-b9d0-3681c1edf024', 'Casa Latina', 'Τριών Ιεραρχών 50, Πετράλωνα, Αθήνα', '2103424321', '2025-05-26 22:47:50'),
(25, '7402f9c4-3a83-11f0-b9d0-3681c1edf024', 'Ramen Nook', 'Αγίου Κωνσταντίνου 18, Ομόνοια, Αθήνα', '2105234567', '2025-05-26 22:47:50'),
(26, '7402fb1f-3a83-11f0-b9d0-3681c1edf024', 'Τα Καρντάσια', 'Λεωφόρος Αλεξάνδρας 122, Αθήνα', '2106428181', '2025-05-26 22:47:50'),
(27, '7402fc5a-3a83-11f0-b9d0-3681c1edf024', 'Steakpoint Athens', 'Αγίας Λαύρας 25, Πατήσια, Αθήνα', '2108312345', '2025-05-26 22:47:50'),
(28, '7402fd9f-3a83-11f0-b9d0-3681c1edf024', 'To Steki Tou Psara', 'Ακτή Ποσειδώνος 90, Πειραιάς', '2104123456', '2025-05-26 22:47:50'),
(29, '7402ff06-3a83-11f0-b9d0-3681c1edf024', 'The Lebanese Table', 'Χαρ. Τρικούπη 125, Εξάρχεια, Αθήνα', '2103804040', '2025-05-26 22:47:50'),
(30, '7403014d-3a83-11f0-b9d0-3681c1edf024', 'Μεζεδάκι Express', 'Γρηγορίου Λαμπράκη 105, Νίκαια, Αθήνα', '2104912345', '2025-05-26 22:47:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_uuid` char(36) NOT NULL DEFAULT uuid(),
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `users`
--

-- Password for the user: rouf123!@# 
INSERT INTO `users` (`user_id`, `user_uuid`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'efeed6ae-08b5-4bfc-bd53-758a8308d29b', 'roufanis', 'roufanis@demo.com', '$2b$10$sI9ifyBISp7V39VAQNYtZ./czC6BAavYQBkjHPrrsEMjGzejdGdCi', '2025-05-26 22:48:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD UNIQUE KEY `reservation_uuid` (`reservation_uuid`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `restaurant_id` (`restaurant_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`restaurant_id`),
  ADD UNIQUE KEY `restaurant_uuid` (`restaurant_uuid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_uuid` (`user_uuid`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `restaurant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`restaurant_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
