// utils/theme.js
import { MD3LightTheme } from 'react-native-paper';

const customTheme = {
    ...MD3LightTheme,
    colors: {
        ...MD3LightTheme.colors,
        primary: '#00796B',         // Teal instead of purple
        secondary: '#B2DFDB',       // Light teal
        error: '#D32F2F'
    }
};

export default customTheme;
