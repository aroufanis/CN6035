import React from 'react';
import { Provider as PaperProvider } from 'react-native-paper';
import { AuthProvider } from './context/AuthContext';
import AppNavigator from './navigation/AppNavigator';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import customTheme from "./utils/theme";

export default function App() {
    return (
        <AuthProvider>
            <SafeAreaProvider>
                <PaperProvider theme={customTheme}>
                    <AppNavigator />
                </PaperProvider>
            </SafeAreaProvider>
        </AuthProvider>
    );
}
